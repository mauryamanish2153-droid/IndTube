# IndTube Android project

This Android Studio project packages the supplied `index.html` as a WebView app and supports selecting video files through Android's file picker.

## Build APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build APK(s)**.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Notes: this wraps the supplied HTML as-is. Features that require a real backend, YouTube API/OAuth, or HTTPS hosting are not made live merely by packaging the HTML.
